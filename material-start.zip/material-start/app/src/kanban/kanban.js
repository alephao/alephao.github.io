(function(){
  angular.module('Kanban', ['ngDraggable']).
  	directive('kanbanBody', function() {
		return {
			restrict: 'E',
			templateUrl: './src/kanban/view/kanban-body.html'
		};	  
	}).
	directive('kanbanBoard', function() {
	  return {
	    restrict: 'E',
	    templateUrl: './src/kanban/view/kanban-board.html',
	    controller:function($scope) {
	      $scope.newCardDescription = "";
	      $scope.cards = [];
	      $scope.addCardFormOn = false;
		  $scope.addButtonClicked = false;
	      $scope.toggleAddCardForm = function() {
	        $scope.addCardFormOn = !$scope.addCardFormOn;
			$scope.newCardDescription = "";
	      };
	      $scope.addCard = function(cardDesc, evt) {
			// if (evt != undefined) {
			// 	evt.stopImmediatePropagation();
			// 	evt.preventDefault();	
			// };
	        $scope.cards.push({description:cardDesc, parentBoard:$scope.board});
	        $scope.newCardDescription = "";
	      };
	      $scope.onDropComplete=function(data,evt){
	        var index = $scope.cards.indexOf(data);
	        if (data == null) return;
	        if (index == -1) {
	          data.parentBoard = $scope.board;
	          $scope.cards.push(data);
	        }
	      };
	      $scope.onDropChangeComplete = function (index, obj, evt) {
	        var otherIndex = $scope.cards.indexOf(obj);
	        $scope.cards.splice(otherIndex, 1);
	        $scope.cards.splice(index, 0, obj);
	      };
	      $scope.cardKeyDown = function(evt) {
	        if (evt.keyCode == 13) { 
				evt.preventDefault();
				$scope.addCard($scope.newCardDescription); 
			};
	      };
	    }
	  };
	}).
	directive('kanbanCard', function() {
	  return {
	    restrict: 'E',
	    templateUrl: './src/kanban/view/kanban-card.html',
	    controller:function($scope) {
	      $scope.parentBoard = null;
		  $scope.cardQuickEditing = false;
	      $scope.setParentBoard = function(data) {
	        $scope.parentBoard = data;
	      };
	      $scope.onDragSuccess = function(data, evt) {
	        var index = $scope.cards.indexOf(data);
	        if (index > -1) {
	            $scope.cards.splice(index, 1);
	        }
	      };
	      $scope.toggleCardQuickEdit = function() {
	        $scope.cardQuickEditing = !$scope.cardQuickEditing;
			if ($scope.cardQuickEditing) {
				$scope.newDescription = $scope.card.description;
			};
	      };
		  $scope.updateCardDescription = function(newDescription) {
			  $scope.card.description = newDescription;
			  $scope.toggleCardQuickEdit();
		  };
	    },
		controllerAs: "cardCtrl"
	  };
	}).
	controller('KanbanCtrl', function ($scope, $mdDialog) {
	  $scope.newBoardTitle = "";
	  $scope.currentEditingCard = null;
	  $scope.boards = [{title:'Board Test'}, {title:'Board Test 2'}];
	  $scope.addBoardFormOn = false;
	  $scope.toggleAddBoardForm = function() {
	    $scope.addBoardFormOn = !$scope.addBoardFormOn;
	  };
	  $scope.addBoard = function(boardName) {
	    $scope.boards.push({title:boardName});
	    $scope.newBoardTitle = "";
	  };
	  $scope.deleteBoard = function(data) {
	    var index = $scope.boards.indexOf(data);
	    $scope.boards.splice(index, 1);
	  };
	  $scope.boardKeyDown = function(evt) {
	    if (evt.keyCode == 13) { 
			evt.preventDefault();
			$scope.addBoard($scope.newBoardTitle);
			// $scope.$apply( function() {
            //     evt.target.focus();    
            // });
		};
	  };
      $scope.showCardEditor = function($event, card) {
       var parentEl = angular.element(document.body);
	   $scope.currentEditingCard = card;
	   console.log();
       $mdDialog.show({
         parent: parentEl,
         targetEvent: $event,
         templateUrl: './src/kanban/view/kanban-edit-card.html',
         locals: {
           currentEditingCard: $scope.currentEditingCard
         },
         controller: DialogController
      });
      function DialogController($scope, $mdDialog, currentEditingCard) {
        $scope.currentEditingCard = currentEditingCard;
        $scope.closeDialog = function() {
          $mdDialog.hide();
        }
      }
    }
	});
})();